// ===== JSON 工具单元测试 =====
import { extractJSON, removeCodeFence, tryRepairTruncatedJSON, safeJSONParse } from './utils/json';
import { normalizeGeneratedResult } from './utils/normalize';
import type { GenerateRequest } from './types';

let passed = 0;
let failed = 0;

function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (e: any) {
    failed++;
    console.log(`  ✗ ${name}: ${e.message}`);
  }
}

function assert(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

function assertEqual(a: any, b: any, msg: string) {
  if (a !== b) throw new Error(`${msg}: expected ${JSON.stringify(b)}, got ${JSON.stringify(a)}`);
}

// ========== removeCodeFence ==========
console.log('\n--- removeCodeFence ---');
test('去除 ```json ... ```', () => {
  const result = removeCodeFence('```json\n{"a":1}\n```');
  assert(result === '{"a":1}', result);
});
test('去除 ``` ... ```', () => {
  const result = removeCodeFence('```\n{"a":1}\n```');
  assert(result === '{"a":1}', result);
});
test('无围栏文本不变', () => {
  const result = removeCodeFence('{"a":1}');
  assert(result === '{"a":1}', result);
});

// ========== extractJSON ==========
console.log('\n--- extractJSON ---');
test('标准完整 JSON', () => {
  const result = extractJSON('{"a":1,"b":2}');
  assert(result === '{"a":1,"b":2}', result);
});
test('Markdown 代码围栏 JSON', () => {
  const result = extractJSON('```json\n{"a":1}\n```');
  assert(result === '{"a":1}', result);
});
test('JSON 前有解释文字', () => {
  const result = extractJSON('这是生成的结果：\n{"a":1}');
  assert(result === '{"a":1}', result);
});
test('JSON 后有解释文字', () => {
  const result = extractJSON('{"a":1}\n以上就是生成的内容。');
  assert(result === '{"a":1}', result);
});
test('数组中提取', () => {
  const result = extractJSON('[1,2,3]');
  assert(result === '[1,2,3]', result);
});

// ========== tryRepairTruncatedJSON ==========
console.log('\n--- tryRepairTruncatedJSON ---');
test('末尾缺失花括号', () => {
  const result = tryRepairTruncatedJSON('{"a":1,"b":{"c":2}');
  // Should add one closing brace
  assert(result.includes('}'), result);
  // Should be parseable - check via safeJSONParse
  const parsed = JSON.parse(result);
  assert(parsed.a === 1, JSON.stringify(parsed));
});
test('末尾缺失方括号', () => {
  const result = tryRepairTruncatedJSON('{"a":[1,2,3');
  const parsed = JSON.parse(result);
  assert(Array.isArray(parsed.a), JSON.stringify(parsed));
  assert(parsed.a.length === 3, JSON.stringify(parsed));
});
test('末尾多余逗号', () => {
  const result = tryRepairTruncatedJSON('{"a":1,}');
  const parsed = JSON.parse(result);
  assert(parsed.a === 1, JSON.stringify(parsed));
});
test('数组末尾多余逗号', () => {
  const result = tryRepairTruncatedJSON('[1,2,3,]');
  const parsed = JSON.parse(result);
  assert(Array.isArray(parsed), JSON.stringify(parsed));
  assert(parsed.length === 3, JSON.stringify(parsed));
});

// ========== safeJSONParse ==========
console.log('\n--- safeJSONParse ---');
test('标准完整 JSON', () => {
  const { data, error } = safeJSONParse('{"name":"test"}');
  assert(error === null, `error: ${error}`);
  assert(data.name === 'test', JSON.stringify(data));
});
test('空输入返回错误', () => {
  const { data, error } = safeJSONParse('');
  assert(data === null, `data: ${JSON.stringify(data)}`);
  assert(error !== null, 'error should not be null');
});
test('完全无效文本返回错误', () => {
  const { data, error } = safeJSONParse('not valid json at all');
  assert(data === null, `data: ${JSON.stringify(data)}`);
  assert(error !== null, 'error should not be null');
});

// ========== normalizeGeneratedResult ==========
console.log('\n--- normalizeGeneratedResult ---');

const baseRequest: GenerateRequest = {
  heritageType: '蜀绣',
  topic: '测试',
  purpose: 'AIGC 比赛',
  duration: '约 1 分钟',
  style: '写实电影',
};

// 构建一个最小化的有效 raw 数据
function makeRaw(overrides: any = {}) {
  return {
    title: '测试作品',
    tagline: '测试一句话',
    story: {
      title: '测试作品',
      tagline: '测试一句话',
      synopsis: '这是一个测试故事梗概，描述蜀绣的传承故事。',
    },
    characters: [{
      name: '小雅', age: '22岁', identity: '大学生',
      appearance: '短发', costume: '休闲装', personality: '好奇',
      relationship: '学生', props: '相机', anchorPoint: '年轻面孔',
    }],
    scenes: [{
      name: '工坊', time: '黄昏', location: '老城',
      atmosphere: '温暖', coreVisualElements: '蜀绣工具',
      allowedElements: '工具', avoidElements: '电子产品',
      colorSuggestion: '暖色', soundElements: '虫鸣',
    }],
    shots: Array.from({ length: 8 }, (_, i) => ({
      id: `shot-${i + 1}`,
      scene: '工坊',
      shotSize: '中景',
      camera: '固定',
      duration: '5秒',
      description: `镜头 ${i + 1} 描述`,
      firstFramePrompt: `首帧 ${i + 1}`,
      lastFramePrompt: `尾帧 ${i + 1}`,
      videoPrompt: `视频 ${i + 1}`,
      generatabilityScore: 85,
      generatabilityChecks: [
        { label: '主体明确', status: 'pass', detail: '清晰' },
      ],
    })),
    soundDesign: {
      bgm: '古筝', ambientSound: '虫鸣', voice: '旁白', soundEffects: '工具声',
    },
    cultureCheck: {
      overallScore: 85,
      items: [{ label: '测试', status: '正常', detail: 'ok' }],
      notes: '测试', suggestions: '测试', disclaimer: '测试',
    },
    submissionNote: {
      title: '测试', introduction: '测试', creativeNote: '测试',
      techNote: '测试', aiUsageNote: '测试', culturalValue: '测试',
      suitableTrack: '测试', specSuggestion: '测试',
    },
    socialPosts: { douyin: '测试', xiaohongshu: '测试' },
    ...overrides,
  };
}

test('shots 只有 5 个，补齐到 8', () => {
  const raw = makeRaw({ shots: Array.from({ length: 5 }, (_, i) => ({
    id: `shot-${i + 1}`, scene: '工坊', shotSize: '中景', camera: '固定',
    duration: '5秒', description: `镜头 ${i + 1}`,
    firstFramePrompt: `首帧 ${i + 1}`, lastFramePrompt: `尾帧 ${i + 1}`,
    videoPrompt: `视频 ${i + 1}`, generatabilityScore: 80,
    generatabilityChecks: [{ label: '主体明确', status: 'pass', detail: 'ok' }],
  }))});
  const result = normalizeGeneratedResult(raw, baseRequest);
  assertEqual(result.shots.length, 8, 'shots count');
  assertEqual(result.shots[0].id, 'shot-1', 'shot 1 id');
  assertEqual(result.shots[7].id, 'shot-8', 'shot 8 id');
});

test('shots 有 10 个，截取到 8', () => {
  const raw = makeRaw({ shots: Array.from({ length: 10 }, (_, i) => ({
    id: `shot-${i + 1}`, scene: '工坊', shotSize: '中景', camera: '固定',
    duration: '5秒', description: `镜头 ${i + 1}`,
    firstFramePrompt: `首帧 ${i + 1}`, lastFramePrompt: `尾帧 ${i + 1}`,
    videoPrompt: `视频 ${i + 1}`, generatabilityScore: 80,
    generatabilityChecks: [{ label: '主体明确', status: 'pass', detail: 'ok' }],
  }))});
  const result = normalizeGeneratedResult(raw, baseRequest);
  assertEqual(result.shots.length, 8, 'shots count');
});

test('镜头字段缺失时补全', () => {
  const raw = makeRaw({
    shots: [{
      id: 'shot-1', scene: '工坊',
      // 缺少多个字段
    }],
  });
  const result = normalizeGeneratedResult(raw, baseRequest);
  assertEqual(result.shots.length, 8, 'shots count');
  // 第一个镜头应被补全
  const shot1 = result.shots[0];
  assertEqual(shot1.id, 'shot-1', 'shot 1 id');
  assert(shot1.shotSize !== undefined, 'shotSize should exist');
  assert(shot1.camera !== undefined, 'camera should exist');
  assert(shot1.description !== undefined, 'description should exist');
  assert(shot1.firstFramePrompt !== undefined, 'firstFramePrompt should exist');
  assert(shot1.lastFramePrompt !== undefined, 'lastFramePrompt should exist');
  assert(shot1.videoPrompt !== undefined, 'videoPrompt should exist');
});

test('generatabilityScore 为字符串时转为数字', () => {
  const raw = makeRaw({ shots: [{
    id: 'shot-1', scene: '工坊', shotSize: '中景', camera: '固定',
    duration: '5秒', description: '镜头 1',
    firstFramePrompt: '首帧', lastFramePrompt: '尾帧',
    videoPrompt: '视频', generatabilityScore: '85', // 字符串
    generatabilityChecks: [{ label: '主体明确', status: 'pass', detail: 'ok' }],
  }]});
  const result = normalizeGeneratedResult(raw, baseRequest);
  const shot1 = result.shots[0];
  assert(typeof shot1.generatabilityScore === 'number', `expected number, got ${typeof shot1.generatabilityScore}`);
  // score 会被重新计算，只需确认是数字
});

test('generatabilityScore 大于 100', () => {
  const raw = makeRaw({ shots: [{
    id: 'shot-1', scene: '工坊', shotSize: '中景', camera: '固定',
    duration: '5秒', description: '镜头 1',
    firstFramePrompt: '首帧', lastFramePrompt: '尾帧',
    videoPrompt: '视频', generatabilityScore: 150,
    generatabilityChecks: [{ label: '主体明确', status: 'pass', detail: 'ok' }],
  }]});
  const result = normalizeGeneratedResult(raw, baseRequest);
  const shot1 = result.shots[0];
  assert(shot1.generatabilityScore <= 100, `score: ${shot1.generatabilityScore}`);
});

test('generatabilityScore 小于 0', () => {
  const raw = makeRaw({ shots: [{
    id: 'shot-1', scene: '工坊', shotSize: '中景', camera: '固定',
    duration: '5秒', description: '镜头 1',
    firstFramePrompt: '首帧', lastFramePrompt: '尾帧',
    videoPrompt: '视频', generatabilityScore: -10,
    generatabilityChecks: [{ label: '主体明确', status: 'pass', detail: 'ok' }],
  }]});
  const result = normalizeGeneratedResult(raw, baseRequest);
  const shot1 = result.shots[0];
  assert(shot1.generatabilityScore >= 0, `score: ${shot1.generatabilityScore}`);
});

test('submissionNote 缺字段时补全', () => {
  const raw = makeRaw({ submissionNote: { title: '只有标题' } });
  const result = normalizeGeneratedResult(raw, baseRequest);
  const sn = result.submissionNote;
  assert(sn.title === '只有标题', `title: ${sn.title}`);
  assert(sn.introduction !== undefined, 'introduction should exist');
  assert(sn.creativeNote !== undefined, 'creativeNote should exist');
  assert(sn.techNote !== undefined, 'techNote should exist');
  assert(sn.aiUsageNote !== undefined, 'aiUsageNote should exist');
  assert(sn.culturalValue !== undefined, 'culturalValue should exist');
  assert(sn.suitableTrack !== undefined, 'suitableTrack should exist');
  assert(sn.specSuggestion !== undefined, 'specSuggestion should exist');
});

test('socialPosts 缺字段时补全', () => {
  const raw = makeRaw({ socialPosts: { douyin: '抖音文案' } });
  const result = normalizeGeneratedResult(raw, baseRequest);
  const sp = result.socialPosts;
  assert(sp.douyin === '抖音文案', `douyin: ${sp.douyin}`);
  assert(sp.xiaohongshu !== undefined, 'xiaohongshu should exist');
});

test('镜头编号最终为 1-8', () => {
  const raw = makeRaw({ shots: [
    { id: 'shot-A', scene: '工坊', shotSize: '中景', camera: '固定', duration: '5秒', description: 'A', firstFramePrompt: 'A', lastFramePrompt: 'A', videoPrompt: 'A', generatabilityScore: 80, generatabilityChecks: [] },
    { id: 'shot-B', scene: '工坊', shotSize: '中景', camera: '固定', duration: '5秒', description: 'B', firstFramePrompt: 'B', lastFramePrompt: 'B', videoPrompt: 'B', generatabilityScore: 80, generatabilityChecks: [] },
  ]});
  const result = normalizeGeneratedResult(raw, baseRequest);
  for (let i = 0; i < result.shots.length; i++) {
    assertEqual(result.shots[i].id, `shot-${i + 1}`, `shot ${i} id`);
  }
});

test('旧 V2.0.1 项目没有 generationMeta', () => {
  const raw = makeRaw();
  delete raw.generationMeta; // 模拟旧项目没有该字段
  // 但 raw 是通过 makeRaw 构建的，它是传给 normalize 的参数
  // normalize 会自己创建 generationMeta
  const result = normalizeGeneratedResult(raw, baseRequest);
  assert(result.generationMeta !== undefined, 'generationMeta should exist');
  assertEqual(result.generationMeta.mode, 'ai', 'mode should be ai');
});

test('旧项目没有 generationHistory（前端逻辑）', () => {
  // generationHistory 是前端 Project 字段，不在 normalize 中处理
  // 只验证 normalize 不依赖它
  const raw = makeRaw();
  const result = normalizeGeneratedResult(raw, baseRequest);
  assert(result.generationMeta !== undefined, 'generationMeta should exist');
});

test('所有 Director 必需字段存在', () => {
  const raw = makeRaw({});
  const result = normalizeGeneratedResult(raw, baseRequest);
  const requiredTop = ['title', 'tagline', 'heritageType', 'purpose', 'duration', 'style', 'story', 'characters', 'scenes', 'shots', 'soundDesign', 'cultureCheck', 'submissionNote', 'socialPosts', 'generationMeta'];
  for (const field of requiredTop) {
    assert(result[field] !== undefined, `top-level ${field} should exist`);
  }
  // story 子字段
  assert(result.story.title !== undefined, 'story.title');
  assert(result.story.tagline !== undefined, 'story.tagline');
  assert(result.story.synopsis !== undefined, 'story.synopsis');
  // soundDesign 子字段
  assert(result.soundDesign.bgm !== undefined, 'soundDesign.bgm');
  assert(result.soundDesign.ambientSound !== undefined, 'soundDesign.ambientSound');
  assert(result.soundDesign.voice !== undefined, 'soundDesign.voice');
  assert(result.soundDesign.soundEffects !== undefined, 'soundDesign.soundEffects');
  // cultureCheck 子字段
  assert(result.cultureCheck.overallScore !== undefined, 'cultureCheck.overallScore');
  assert(Array.isArray(result.cultureCheck.items), 'cultureCheck.items');
  // submissionNote 子字段
  assert(result.submissionNote.title !== undefined, 'submissionNote.title');
  // socialPosts 子字段
  assert(result.socialPosts.douyin !== undefined, 'socialPosts.douyin');
  assert(result.socialPosts.xiaohongshu !== undefined, 'socialPosts.xiaohongshu');
});

// ========== 结果汇总 ==========
console.log(`\n========== 测试结果: ${passed} 通过, ${failed} 失败 ==========`);
if (failed > 0) {
  process.exit(1);
}